(function () {
    jasmine.getFixtures().fixturesPath = "./spec/fixtures/";
})();
