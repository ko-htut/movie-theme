describe("justlazy should", function () {

    it("be initialized", function () {
        expect(Justlazy).not.toBeUndefined();
    });
});
